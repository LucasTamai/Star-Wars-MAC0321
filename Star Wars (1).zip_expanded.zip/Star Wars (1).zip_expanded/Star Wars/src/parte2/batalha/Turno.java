package parte2.batalha;

import java.util.List;

public class Turno {
	private List<Personagens> personagens;
	private int AcaoPersonagem1;
	private int AcaoPersonagem2;
	
	public List<Personagens> getPersonagens() {
		return personagens;
	}
	public void setPersonagens(List<Personagens> personagens) {
		this.personagens = personagens;
	}
	
	private int Prioridade() {
		if (personagem1.acao < personagem2.acao)
			return 2;
		else
			return 1;
	}

	private int CalculaDano(Personagens personagem) {
		personagem.habilidadeDano<acaoPersonagem> * dominioForca; ?
	}

	private int ExecutaA��o() {
		
	}

	public boolean Turno(List<Personagens> personagens; int AcaoPersonagem1; int AcaoPersonagem2) {
		if (Prioridade())
	}
