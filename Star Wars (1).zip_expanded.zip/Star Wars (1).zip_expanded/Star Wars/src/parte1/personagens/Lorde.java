package parte1.personagens;

import java.util.List;

public class Lorde extends Aprendiz{
    private List<Aprendiz> aprendizList;


    public List<Aprendiz> getAprendizList() {
        return aprendizList;
    }

    public void setAprendizList(List<Aprendiz> aprendizList) {
        this.aprendizList = aprendizList;
    }
}
