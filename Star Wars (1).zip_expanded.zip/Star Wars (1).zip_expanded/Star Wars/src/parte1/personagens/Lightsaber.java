package parte1.personagens;

public class Lightsaber {
	private int cristal[]; // (indice 0 - define se ja coletou o cristal; indices 1 2 e 3 - cores referentes a RGB)
	private int hilt; // (0 - nao possui sabre de luz; 1 - espada; 2 - lança;3 chicote; 4 tonfa)

	public int[] getCristal() {
		return cristal;
	}

	public void setCristal(int[] cristal) {
		this.cristal = cristal;
	}

	public int getHilt() {
		return hilt;
	}

	public void setHilt(int hilt) {
		this.hilt = hilt;
	}
}
