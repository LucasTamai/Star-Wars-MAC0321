package parte2.batalha;


import parte1.personagens.Ser;

public class Personagens {

	private Ser personagem;
	private double vida;
	private int dominioSabre;
	private int dominioforca;
	private String habilidades[];
	private int habilidadesdano[];	
	
	

	public Ser getPersonagem() {
		return personagem;
	}

	public void setPersonagem(Ser personagem) {
		this.personagem = personagem;
	}

	public int getDominioSabre() {
		return dominioSabre;
	}

	public void setDominioSabre(int dominioSabre) {
		this.dominioSabre = dominioSabre;
	}

	

	public int getDominioforca() {
		return dominioforca;
	}

	public void setDominioforca(int dominioforca) {
		this.dominioforca = dominioforca;
	}

	public String[] getHabilidades() {
		return habilidades;
	}

	public void setHabilidades(String[] habilidades) {
		this.habilidades = habilidades;
	}

	public int[] getHabilidadesdano() {
		return habilidadesdano;
	}

	public void setHabilidadesdano(int[] habilidadesdano) {
		this.habilidadesdano = habilidadesdano;
	}
		
	public double getVida() {
		return vida;
	}

	public void setVida(double vida) {
		this.vida = vida;
	}
	
	
	public void esquivar() {
		System.out.println("O personagem"+ getPersonagem() + "esquivou!");
	}

}
