package parte2.batalha;


public class Turno {
	private Personagens personagem1;
	private Personagens personagem2;
	
	
	public Personagens getPersonagem1() {
		return personagem1;
	}

	public void setPersonagem1(Personagens personagem1) {
		this.personagem1 = personagem1;
	}

	public Personagens getPersonagem2() {
		return personagem2;
	}

	public void setPersonagem2(Personagens personagem2) {
		this.personagem2 = personagem2;
	}

	private int Prioridade() {     // retorna qual personagem tem a prioridade
		if (personagem1.getAcaoPersonagem() < personagem2.getAcaoPersonagem())
			return 2;
		else
			return 1;
	}

	private int CalculaDano(Personagens personagem1) {
		int dano;
		dano = personagem1.getHabilidadesdano() * personagem1.getDominioforca();
		return dano;
	}

		boolean ExecutaAcao(int personag, int dano) {
		boolean morreu = false;
		if (personag == 1) {
			personagem1.setVida(personagem1.getVida() - dano);
			if (personagem1.getVida() <= 0) {
				morreu = true;
			}
		}
		else {
			personagem2.setVida(personagem2.getVida()-dano);
				if (personagem2.getVida() <= 0) {
				morreu = true;
				}	
			}
		return morreu;	
		}
	
	public boolean Turnos(Personagens personagem1,Personagens personagem2) {
		int dano;
		int recebe;
		while(Turnos(personagem1,personagem2) == true) {
		if (Prioridade() == 1) {
			dano = CalculaDano(personagem1);
			recebe = 2;
			if (ExecutaAcao(recebe,dano)==true) return false;
			}
		else {
			dano = CalculaDano(personagem2);
			recebe = 1;
			if (ExecutaAcao(recebe, dano) == true) return false;
		}
		   
	}
		return true;
	}
}

