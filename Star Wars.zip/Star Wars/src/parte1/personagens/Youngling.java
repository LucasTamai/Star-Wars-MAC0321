package parte1.personagens;

public class Youngling extends Jedi {

}
