package parte1.personagens;

public class Padawan extends Youngling{
	private int tranca; //(comprimento em cm)
	private boolean conhecimento; // (0 - nao possui conhecimento para construcao do sabre de luz)
	private Mestre mestre;

	public int getTranca() {
		return tranca;
	}

	public void setTranca(int tranca) {
		this.tranca = tranca;
	}

	public boolean isConhecimento() {
		return conhecimento;
	}

	public void setConhecimento(boolean conhecimento) {
		this.conhecimento = conhecimento;
	}

	public Mestre getMestre() {
		return mestre;
	}

	public void setMestre(Mestre mestre) {
		this.mestre = mestre;
	}
}
