package parte1.personagens;

public class Mestre extends Knight{
	private int habilidade[]; //(indice 0 - imortalidade(bool); indice - 1 Tamanho do campo de videncia(km))
	private Cla LiderCla;
	private Padawan Liderpadawan;


	public int[] getHabilidade() {
		return habilidade;
	}

	public void setHabilidade(int[] habilidade) {
		this.habilidade = habilidade;
	}

	public Cla getLiderCla() {
		return LiderCla;
	}

	public void setLiderCla(Cla liderCla) {
		LiderCla = liderCla;
	}

	public Padawan getLiderpadawan() {
		return Liderpadawan;
	}

	public void setLiderpadawan(Padawan liderpadawan) {
		Liderpadawan = liderpadawan;
	}
}
