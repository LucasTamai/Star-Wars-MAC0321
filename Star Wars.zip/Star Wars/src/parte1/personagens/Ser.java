package parte1.personagens;

import parte1.universo.Planeta;

public class Ser {
	private String Nome;
	private String especie;
	private int anoNascimento;
	private int midc;
	private Planeta origem;
	private Alinhamento alinhamento;
	private double vida;


	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public int getAnoNascimento() {
		return anoNascimento;
	}

	public void setAnoNascimento(int anoNascimento) {
		this.anoNascimento = anoNascimento;
	}

	public int getMidc() {
		return midc;
	}

	public void setMidc(int midc) {
		this.midc = midc;
	}

	public Planeta getOrigem() {
		return origem;
	}

	public void setOrigem(Planeta origem) {
		this.origem = origem;
	}

	public Alinhamento getAlinhamento() {
		return alinhamento;
	}

	public void setAlinhamento(Alinhamento alinhamento) {
		this.alinhamento = alinhamento;
	}
	
	public double getVida() {
		return vida;
	}

	public void setVida(int vida) {
		this.vida = vida;
	}
}
