package parte1.personagens;

public class Knight extends Padawan{
	int DataAprovacao;

	public int getDataAprovacao() {
		return DataAprovacao;
	}

	public void setDataAprovacao(int dataAprovacao) {
		DataAprovacao = dataAprovacao;
	}
}
