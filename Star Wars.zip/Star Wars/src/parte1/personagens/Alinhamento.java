package parte1.personagens;

public class Alinhamento {
	private Ordem ordem;
	private int percentual; //Percentual de raiva ou de paz interior de um ser (definido em Ordem)
	private String[] poderes;
	private Lightsaber lightsaber; //Segura as informa��es de um sabre de luz de um ser


	public Alinhamento() {

	}

	public Alinhamento(int percentual, String[] poderes) {
		this.percentual = percentual;
		this.poderes = poderes;
	}


	public int getPercentual() {
		return percentual;
	}

	public void setPercentual(int percentual) {
		this.percentual = percentual;
	}

	public Ordem getOrdem() {
		return ordem;
	}

	public void setOrdem(Ordem ordem) {
		this.ordem = ordem;
	}

	public String[] getPoderes() {
		return poderes;
	}

	public void setPoderes(String[] poderes) {
		this.poderes = poderes;
	}
	
	public Lightsaber getLightsaber() {
		return lightsaber;
	}

	public void setLightsaber(Lightsaber lightsaber) {
		this.lightsaber = lightsaber;
	}
}