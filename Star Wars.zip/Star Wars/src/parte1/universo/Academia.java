package parte1.universo;

public class Academia {
	private String nome;
	private Planeta planetaOrigem;
	private Conselho conselho;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Planeta getPlanetaOrigem() {
		return planetaOrigem;
	}

	public void setPlanetaOrigem(Planeta planetaOrigem) {
		this.planetaOrigem = planetaOrigem;
	}

	public Conselho getConselho() {
		return conselho;
	}

	public void setConselho(Conselho conselho) {
		this.conselho = conselho;
	}
}
