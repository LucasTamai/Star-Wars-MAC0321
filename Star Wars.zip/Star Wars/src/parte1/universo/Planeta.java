package parte1.universo;

public class Planeta {
	private String cor;
	private int diametro;
	private String nome;
	private String capital;
	private RegimePolitico reg;
	private Sistema sistema;

	public Planeta(String cor, int diametro, String nome, String capital, Sistema sistema) {
		this.cor = cor;
		this.diametro = diametro;
		this.nome = nome;
		this.capital = capital;
		this.sistema = sistema;
	}

	public Planeta(String cor, int diametro, String nome, String capital, RegimePolitico reg, Sistema sistema) {
		this.cor = cor;
		this.diametro = diametro;
		this.nome = nome;
		this.capital = capital;
		this.reg = reg;
		this.sistema = sistema;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public int getDiametro() {
		return diametro;
	}

	public void setDiametro(int diametro) {
		this.diametro = diametro;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCapital() {
		return capital;
	}

	public void setCapital(String capital) {
		this.capital = capital;
	}

	public RegimePolitico getReg() {
		return reg;
	}

	public void setReg(RegimePolitico reg) {
		this.reg = reg;
	}

	public Sistema getSistema() {
		return sistema;
	}

	public void setSistema(Sistema sistema) {
		this.sistema = sistema;
	}
}
