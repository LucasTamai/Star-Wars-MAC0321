package parte1.universo;

import java.util.*;

public class RegimePolitico {
	private String Nome;
	private int instituido;
	private int dissolvido;
	private String capital;
	private List<Planeta> planetas;
	
	RegimePolitico(String Nome, int instituido, int dissolvido, String capital, List<Planeta> planetas) {
		this.Nome = Nome;
		this.instituido = instituido;
		this.dissolvido = dissolvido;
		this.capital = capital;
		this.planetas = planetas;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public int getInstituido() {
		return instituido;
	}

	public void setInstituido(int instituido) {
		this.instituido = instituido;
	}

	public int getDissolvido() {
		return dissolvido;
	}

	public void setDissolvido(int dissolvido) {
		this.dissolvido = dissolvido;
	}

	public String getCapital() {
		return capital;
	}

	public void setCapital(String capital) {
		this.capital = capital;
	}

	public List<Planeta> getPlanetas() {
		return planetas;
	}

	public void setPlanetas(List<Planeta> planetas) {
		this.planetas = planetas;
	}

	public void addPlaneta(Planeta planeta){
		planetas.add(planeta);
	}
}
